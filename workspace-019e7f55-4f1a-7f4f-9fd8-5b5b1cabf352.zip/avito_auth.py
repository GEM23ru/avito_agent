"""
🔐 avito_auth.py — отдельный скрипт авторизации Selenium-агента в Авито.

Запускается ОДИН РАЗ перед оркестратором. Открывает Chrome в выделенном
профиле «Агент», даёт вам войти руками (логин/пароль/SMS), затем эта
авторизация переиспользуется оркестратором — куки и сессия лежат в том же
профиле, и повторно входить не нужно.

Параллельно ваш личный Chrome продолжает работать как обычно, потому что
это ДРУГОЙ профиль (см. CHROME_USER_DATA / CHROME_PROFILE ниже).
"""

import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

# ⚠️ ВАЖНО: путь и имя профиля должны СОВПАДАТЬ с теми, что использует оркестратор!
# Иначе оркестратор откроется в "пустом" профиле без авторизации, и придётся логиниться заново.
CHROME_USER_DATA = r"C:\Users\test123\AppData\Local\Google\Chrome\User Data"
CHROME_PROFILE = "Profile 1"


def create_driver():
    options = webdriver.ChromeOptions()
    options.add_argument(f"--user-data-dir={CHROME_USER_DATA}")
    options.add_argument(f"--profile-directory={CHROME_PROFILE}")
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    options.add_argument('--window-size=1920,1080')

    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options,
    )
    driver.execute_script(
        "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    )
    return driver


def check_auth(driver):
    print("🌐 Открываю Авито...")
    driver.get("https://www.avito.ru/profile")
    time.sleep(4)
    if "login" in driver.current_url or "signin" in driver.current_url:
        print("❌ Не авторизован — войди на Авито вручную в профиле Агент")
        return False
    print("✅ Авторизован на Авито!")
    return True


if __name__ == "__main__":
    print("=" * 50)
    print("🔐 АВТОРИЗАЦИЯ — профиль Агент")
    print("=" * 50)
    print("✅ Твой Chrome продолжает работать как обычно!")
    print()

    driver = create_driver()
    try:
        authorized = check_auth(driver)
        if authorized:
            print("🎉 Готово! Агент работает в отдельном профиле.")
            print("Теперь можно запускать orchestrator.py")
            print("пока твой Chrome открыт!")
        else:
            print("Войди на Авито вручную в открывшемся окне.")
        input("\nНажми Enter чтобы закрыть...")
    finally:
        driver.quit()
