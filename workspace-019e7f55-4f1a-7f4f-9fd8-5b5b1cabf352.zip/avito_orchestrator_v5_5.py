"""
🧠 ОРКЕСТРАТОР v5.5 (САМООБУЧАЮЩИЙСЯ) — Архитектура Ruflo
Магазин парфюмерии Евгения, г. Анапа.

Цепочка из 6 ИИ-агентов:
  1. agent_collector — собирает мои объявления (без захода в карточки → CPC не скликивается)
  2. agent_seo      — ключевики + новый заголовок (≤50 симв.)
  3. agent_price    — анализ цен с фильтром оригиналов
  4. agent_photo    — советы по фото
  5. agent_text     — продающее описание 600–1000 симв. без стоп-слов
  6. agent_status   — статус и рекомендация по действию

Особенности:
  • OpenRouter + бесплатная модель meta-llama/llama-3.3-70b-instruct:free
  • Изолированный профиль Chrome (не конфликтует с личным)
  • Самообучение: память берётся из avito_export.csv → avito_agent_memory.json
  • Жёсткие правила безопасности: ни одного стоп-слова, ни одного упоминания «Москвы»,
    последняя строка описания всегда — «Авито Доставка или самовывоз, Анапа.»
"""

import os
import re
import time
import random
import datetime
import json
import csv

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openai import OpenAI
from dotenv import load_dotenv

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

load_dotenv(encoding='utf-8')

# Принудительно отключаем системные прокси — мешают Selenium и OpenRouter
os.environ['HTTP_PROXY'] = ''
os.environ['HTTPS_PROXY'] = ''
os.environ['http_proxy'] = ''
os.environ['https_proxy'] = ''

MY_PROFILE_URL = (
    "https://www.avito.ru/brands/c494d24667a34f39ee8a2bfd9d5e67fa/items/all"
    "?s=profile_search_show_all&sellerId=f5b44d614ca1fbd1a3a2c9c311810df2"
)

# Абсолютно изолированный профиль — исключает любые конфликты с личным Chrome
CHROME_USER_DATA = r"C:\avito_agent\chrome_profile"

# ============================================================
# УМНЫЕ ПАУЗЫ
# ============================================================

request_count = 0
session_start = datetime.datetime.now()

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
]


def smart_pause(request_num):
    global request_count
    request_count += 1
    if request_count % 20 == 0:
        t = random.uniform(120, 180)
        print(f"   ☕ Большая пауза {t/60:.1f} мин — даём Авито отдохнуть...")
        time.sleep(t)
    elif request_count % 5 == 0:
        t = random.uniform(25, 40)
        print(f"   ⏸️  Длинная пауза {t:.0f} сек...")
        time.sleep(t)
    else:
        time.sleep(random.uniform(8, 15))


def human_scroll(driver):
    for _ in range(4):
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)


def check_blocked(driver):
    """Проверяет реальную блокировку по URL и заголовку страницы."""
    current_url = driver.current_url
    title = driver.title.lower()

    block_urls = ['blocked', 'captcha', 'sorry', 'deny']
    block_titles = ['доступ ограничен', 'доступ с вашего ip', 'captcha']

    url_blocked = any(b in current_url.lower() for b in block_urls)
    title_blocked = any(b in title for b in block_titles)

    if url_blocked or title_blocked:
        print(f"\n🚫 Блокировка! URL: {current_url}")
        print("   Жду 5 минут...")
        time.sleep(300)
        driver.refresh()
        time.sleep(5)
        return any(b in driver.current_url.lower() for b in block_urls)

    return False


# ============================================================
# ЯДРО — OpenRouter + очистка markdown
# ============================================================

client = OpenAI(
    api_key=os.getenv("OPENROUTER_API_KEY"),
    base_url="https://openrouter.ai/api/v1",
)


def ask_ai(prompt, system_role="Ты эксперт по продажам на Авито"):
    try:
        response = client.chat.completions.create(
            model="meta-llama/llama-3.3-70b-instruct:free",
            messages=[
                {"role": "system", "content": system_role},
                {"role": "user", "content": prompt},
            ],
            max_tokens=1000,
        )
        text = response.choices[0].message.content.strip()
        # Чистим markdown — Авито его не рендерит
        text = re.sub(r'\*+', '', text)
        text = re.sub(r'#+\s?', '', text)
        text = re.sub(r'`+', '', text)
        text = re.sub(r'__+', '', text)
        text = re.sub(r'\[.*?\]\(.*?\)', '', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()
    except Exception as e:
        return f"❌ Ошибка ИИ: {e}"


# ============================================================
# СИСТЕМА САМООБУЧЕНИЯ (Ruflo Self-Learning Loop) 🧠
# ============================================================

def update_agent_memory():
    """Считывает выгрузку из Авито Pro и формирует базу успешных паттернов."""
    memory_file = "avito_agent_memory.json"
    stats_file = "avito_export.csv"  # путь к выгрузке из Авито Pro

    memory_data = {
        "success_stories": [
            {
                "title": "Dolce&Gabbana L’Imperatrice 3 33 мл тестер духов",
                "price": "500 ₽",
                "metric": "2 заказа, 8 добавлений в избранное",
                "type": "Фруктово-свежий",
            },
            {
                "title": "Tom Ford White Patchouli EDP 100 мл",
                "price": "1 500 ₽",
                "metric": "2 заказа, 1 добавление в избранное",
                "type": "Селективный нишевый",
            },
        ]
    }

    if os.path.exists(stats_file):
        try:
            with open(stats_file, 'r', encoding='utf-8') as f:
                rows = list(csv.reader(f))

            headers = rows[0]
            data_rows = rows[1:]

            title_idx = headers.index('Название объявления')
            price_idx = headers.index('Цена')
            fav_idx = headers.index('Добавили в избранное')
            orders_idx = headers.index('Заказано товаров')
            contacts_idx = headers.index('Контакты')

            success_stories = []
            for r in data_rows:
                if len(r) < len(headers):
                    continue
                try:
                    orders = int(re.sub(r'\D', '', r[orders_idx])) if r[orders_idx] else 0
                    contacts = int(re.sub(r'\D', '', r[contacts_idx])) if r[contacts_idx] else 0
                    favs = int(re.sub(r'\D', '', r[fav_idx])) if r[fav_idx] else 0

                    if orders > 0 or contacts >= 2 or favs >= 4:
                        success_stories.append({
                            "title": r[title_idx].strip(),
                            "price": r[price_idx].strip(),
                            "metric": f"{orders} заказов, {contacts} контактов, {favs} в избранном",
                        })
                except Exception:
                    continue

            if success_stories:
                memory_data["success_stories"] = success_stories
                print(f"🧠 [САМООБУЧЕНИЕ] Обнаружено {len(success_stories)} успешных паттернов. Робот запомнил их!")
        except Exception as e:
            print(f"⚠️ Ошибка при анализе статистики для самообучения: {e}")

    with open(memory_file, 'w', encoding='utf-8') as f:
        json.dump(memory_data, f, ensure_ascii=False, indent=4)


def load_success_examples():
    """Загружает топ-успешных паттернов для инъекции в промт ИИ."""
    memory_file = "avito_agent_memory.json"
    if os.path.exists(memory_file):
        try:
            with open(memory_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            stories = data.get("success_stories", [])
            examples = [
                f"- '{s['title']}' за {s['price']} (Метрика успеха: {s['metric']})"
                for s in stories[:3]
            ]
            return "\n".join(examples)
        except Exception:
            pass
    return "Примеры отсутствуют."


# ============================================================
# ДРАЙВЕР (НА КРИСТАЛЬНО ЧИСТОМ ИЗОЛИРОВАННОМ ПРОФИЛЕ!)
# ============================================================

def create_driver():
    options = webdriver.ChromeOptions()
    options.add_argument(f"--user-data-dir={CHROME_USER_DATA}")
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    options.add_argument('--window-size=1920,1080')
    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options,
    )
    driver.execute_script(
        "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    )
    return driver


# ============================================================
# АГЕНТ 1 — СБОРЩИК (без захода на объявления)
# ============================================================

def agent_collector(driver, max_items=89):
    print("\n" + "=" * 50)
    print("🤖 АГЕНТ 1: СБОРЩИК")
    print("⚠️  Режим: БЕЗ захода на объявления — просмотры не скликиваются")
    print("=" * 50)

    driver.get(MY_PROFILE_URL)
    time.sleep(6)

    if check_blocked(driver):
        return []

    listings = []
    seen_links = set()
    page = 1

    while len(listings) < max_items:
        print(f"   📄 Страница {page}...")
        time.sleep(3)

        items = driver.find_elements(By.CSS_SELECTOR, '[class*="iva-item"]')
        if not items:
            print("   ⚠️ Объявления не найдены")
            break

        for item in items:
            if len(listings) >= max_items:
                break
            try:
                title = item.find_element(By.CSS_SELECTOR, '[data-marker="item-title"]').text.strip()
                price = item.find_element(By.CSS_SELECTOR, '[data-marker="item-price"]').text.strip()
                link = item.find_element(By.CSS_SELECTOR, 'a[itemprop="url"]').get_attribute('href')

                if not title or link in seen_links:
                    continue

                description = ""
                try:
                    meta = item.find_element(By.CSS_SELECTOR, 'meta[itemprop="description"]')
                    description = meta.get_attribute('content').strip()
                except Exception:
                    pass

                photos_count = 0
                try:
                    photos = item.find_elements(By.CSS_SELECTOR, 'img')
                    photos_count = max(0, len(photos) - 1)
                except Exception:
                    pass

                seen_links.add(link)
                listings.append({
                    'title': title,
                    'price': price,
                    'link': link,
                    'description': description,
                    'photos_count': photos_count,
                    'views': 0,
                    'contacts': 0,
                    'favorites': 0,
                    'seo_keywords': '',
                    'seo_title': '',
                    'seo_keyword_analysis': '',
                    'price_analysis': '',
                    'photo_advice': '',
                    'new_description': '',
                    'status': '',
                    'action': '',
                })
            except Exception:
                continue

        print(f"   ✅ Собрано: {len(listings)}")

        prev_count = len(seen_links)
        human_scroll(driver)
        time.sleep(3)

        new_items = driver.find_elements(By.CSS_SELECTOR, '[class*="iva-item"]')
        if len(new_items) <= len(items) and len(seen_links) == prev_count:
            print("   ℹ️ Новых объявлений нет — завершаю сбор")
            break

        page += 1

    print(f"✅ АГЕНТ 1 завершил: {len(listings)} объявлений")
    return listings


# ============================================================
# АГЕНТ 2 — SEO (двухшаговый, с адаптивной памятью)
# ============================================================

def agent_seo(listing, competitors):
    competitors_titles = "\n".join([
        f"- {c['title']} | {c['price']}" for c in competitors
    ]) or "Нет данных"

    success_examples = load_success_examples()

    keyword_prompt = f"""Ты SEO-специалист по Авито. Найди реальные поисковые запросы покупателей.

ТОВАР: {listing['title']}

ОБЪЯВЛЕНИЯ КОНКУРЕНТОВ:
{competitors_titles}

ЭТАЛОННЫЕ ЛОТЫ ИЗ НАШЕЙ ПАМЯТИ УСПЕШНЫХ ПРОДАЖ:
{success_examples}

Проанализируй и выполни:

ВЫСОКОЧАСТОТНЫЕ запросы (ищут часто):
[3-4 фразы]

СРЕДНЕЧАСТОТНЫЕ запросы (ищут регулярно):
[3-4 фразы]

НИЗКОЧАСТОТНЫЕ запросы (ищут точечно):
[2-3 фразы]

ГЛАВНЫЕ 7 СЛОВ ДЛЯ ЗАГОЛОВКА (через запятую):
[перечисли без форматирования]"""

    keyword_result = ask_ai(
        keyword_prompt,
        system_role="Ты SEO-специалист маркетплейсов. Отвечай чётко по формату. Никакого markdown.",
    )

    title_prompt = f"""Напиши заголовок для объявления на Авито.

ТОВАР: {listing['title']}
ЦЕНА: {listing['price']}
ГОРОД ПРОДАВЦА: Анапа, Краснодарский край
КЛЮЧЕВЫЕ СЛОВА:
{keyword_result}

ПРАВИЛА:
- Длина ровно до 50 символов (СТРОГО, Авито не пропустит длиннее!).
- Первым словом пиши категорию: "Духи", "Парфюм", "Мужские духи", "Женские духи" или "Мини-парфюм" (это главный поисковый ключ!).
- Название бренда пиши на английском, а если помещается — добавь в скобках или через пробел на русском (например: "Montale (Монталь)" или "Thomas Kosmala Томас Космала"). Это удвоит поисковые просмотры!
- Пол: мужские / женские / унисекс (если применимо).
- Обязательно укажи объем: "100 мл", "25 мл", "200 мл" и т.д.
- ЗАПРЕЩЕНО писать слова: "Авито Доставка", "Москва", "копия", "реплика", "ОАЭ", "аналог", "оригинал".
- Никаких восклицательных знаков и лишних спецсимволов.
- Никакого форматирования — только текст в одну строку.

Проверь длину заголовка перед выдачей. Напиши только заголовок. Одна строка."""

    new_title = ask_ai(
        title_prompt,
        system_role="Ты копирайтер для Авито. Пишешь только заголовок — одну строку без форматирования.",
    )

    lines = keyword_result.split('\n')
    keywords_line = ""
    for i, line in enumerate(lines):
        if 'главны' in line.lower() or '7 слов' in line.lower() or 'заголовка' in line.lower():
            if i + 1 < len(lines):
                keywords_line = lines[i + 1].strip()
            break
    if not keywords_line and lines:
        keywords_line = lines[-1].strip()

    listing['seo_keywords'] = keywords_line
    listing['seo_title'] = new_title
    listing['seo_keyword_analysis'] = keyword_result
    return listing


# ============================================================
# АГЕНТ 3 — ЦЕНА (с умным фильтром оригиналов)
# ============================================================

def agent_price(listing, competitors):
    try:
        my_price_val = int(re.sub(r'\D', '', listing['price']))
    except Exception:
        my_price_val = 1500

    competitors_prices = "\n".join([
        f"- {c['title']}: {c['price']}" for c in competitors
    ]) or "Нет данных"

    prompt = f"""Ты аналитик цен на Авито для парфюмерии класса ЛЮКС-ТЕСТЕР (производство Дубай).
Внимание: наш сегмент — качественные люкс-тестеры и масла, их средняя рыночная цена составляет 1200–1800 руб за 100 мл.
Если среди конкурентов в списке ниже попадаются ОРИГИНАЛЫ с ценами более 3500–25000 руб, игнорируй эти высокие оригинальные цены! Нам нельзя конкурировать с оригинальным рынком.

МОЁ ОБЪЯВЛЕНИЕ:
Товар: {listing['title']}
Моя цена: {listing['price']}

КОНКУРЕНТЫ:
{competitors_prices}

Посчитай среднюю цену конкурентов исключительно в сегменте люкс-тестеров/копий. Если все конкуренты продают дорогие оригиналы, установи рекомендуемую цену в диапазоне 1400–1800 руб (или оставь мою цену {listing['price']}).

Отвечай строго в таком формате без форматирования:

СРЕДНЯЯ ЦЕНА КОНКУРЕНТОВ: [число] руб
РЕКОМЕНДУЕМАЯ ЦЕНА: [число] руб
МОЯ ПОЗИЦИЯ: [дешевле рынка / в рынке / дороже рынка]
ВЫВОД: [одно предложение что делать с ценой, исходя строго из сегмента люкс-тестеров/масел]"""

    result = ask_ai(
        prompt,
        system_role="Ты аналитик цен в сегменте люкс-парфюмерии. Отвечай строго по формату без markdown.",
    )

    try:
        rec_price_match = re.search(r'РЕКОМЕНДУЕМАЯ ЦЕНА:\s*(\d+)', result)
        if rec_price_match:
            rec_price_val = int(rec_price_match.group(1))
            if rec_price_val > 3000 and my_price_val <= 1800:
                result = re.sub(
                    r'РЕКОМЕНДУЕМАЯ ЦЕНА: \d+ руб',
                    f'РЕКОМЕНДУЕМАЯ ЦЕНА: {my_price_val} руб',
                    result,
                )
                result = re.sub(
                    r'МОЯ ПОЗИЦИЯ: .*',
                    'МОЯ ПОЗИЦИЯ: в рынке (люкс-тестеры)',
                    result,
                )
                result += "\n⚠️ Примечание: ИИ отфильтровал завышенные цены оригиналов. Сохраняйте цену для тестера."
    except Exception:
        pass

    listing['price_analysis'] = result
    return listing


# ============================================================
# АГЕНТ 4 — ФОТО
# ============================================================

def agent_photo(listing):
    warn = ("КРИТИЧНО: фото меньше 5 штук — это убивает продажи! Скажи об этом первым пунктом."
            if listing['photos_count'] < 5 else "")

    prompt = f"""Ты эксперт по продажам на Авито.

Товар: {listing['title']}
Фото в объявлении: {listing['photos_count']} шт.

{warn}

Дай 3 конкретных совета по фото для роста продаж.
Пиши простым текстом без форматирования.
Каждый совет с новой строки начиная с цифры."""

    result = ask_ai(
        prompt,
        system_role="Ты эксперт по визуальному контенту. Пишешь простым текстом без форматирования.",
    )
    listing['photo_advice'] = result
    return listing


# ============================================================
# АГЕНТ 5 — ТЕКСТ (с памятью самообучения, без стоп-слов)
# ============================================================

def agent_text(listing):
    keywords = listing.get('seo_keywords', '')
    success_examples = load_success_examples()
    current_desc = listing['description'][:400] if listing['description'] else 'отсутствует'

    prompt = f"""Ты — выдающийся копирайтер и эксперт по продажам парфюмерии на Авито.
Твоя задача — написать безопасное, дорогое и продающее описание для объявления на тарифе CPC (оплата за клик).

ТОВАР: {listing['title']}
ЦЕНА: {listing['price']}
ТЕКУЩЕЕ ОПИСАНИЕ: {current_desc}
КЛЮЧЕВЫЕ СЛОВА: {keywords}

НАША ЛОКАЛЬНАЯ ПАМЯТЬ УСПЕШНЫХ ПРОДАЖ (Ориентируйся на этот стиль структуры и подачи):
{success_examples}

СТРОГИЕ ПРАВИЛА БЕЗОПАСНОСТИ (Защита от блокировок):
1. КАТЕГОРИЧЕСКИ ЗАПРЕЩЕНО использовать слова: "ОАЭ", "реплика", "копия", "аналог", "1 в 1", "1:1", "ААА+", "дубликат", "имитация", "подделка", "фейк", "оригинал". Если в текущем описании есть эти слова — удали их безвозвратно!
2. Для обозначения высокого качества используй исключительно безопасные фразы: "Премиальное качество (Дубай)", "Люкс-тестер (Premium)", "Качество Люкс", "Исполнение: Европа", "Батч-код бьется/совпадает на коробке и флаконе".
3. ЗАПРЕЩЕНО упоминать города "Москва", "м.", "метро". Продавец из Анапы! Последняя строка описания ВСЕГДА должна быть: "Авито Доставка или самовывоз, Анапа."

ПРАВИЛА КОНВЕРСИИ ДЛЯ ТАРИФА CPC (Снижение скликивания):
4. Не используй воду и канцелярит. Начни сразу с названия товара, его объема и главного факта. Например: "Мужские духи [Бренд] [Название] [Объем] мл в премиальном исполнении люкс-тестера!"
5. Честно распиши состояние товара: коробка запечатана в слюду, состояние флакона идеальное. (Если в текущем описании указаны дефекты коробки или уценка — перенеси это в новый текст со специальной пометкой "ВНИМАНИЕ (Уценка за дефект упаковки)").
6. Напиши пирамиду нот аромата (Верхние, Средние, Базовые), если они известны. Опиши стойкость (в среднем 4–6 часов на коже, до суток на одежде) и характер шлейфа простым человеческим языком.
7. Добавь интерактивный триггер для чата (Акция): "Напишите мне в чат кодовое слово [КЛЮЧЕВОЕ СЛОВО на тему аромата] прямо сейчас — и к вашему заказу я бесплатно добавлю мини-пробник другого селективного парфюма в подарок!"
8. Обязательно вставь блок про покупку нескольких товаров со скидкой через Корзину (это увеличивает средний чек):
   "🛒 ХОТИТЕ СЭКОНОМИТЬ? Добавьте этот товар в корзину Авито вместе с другими ароматами из моего профиля (у меня их более 80!). При заказе от 2-х любых позиций вы получите скидку 5% в корзине и заплатите за доставку всего один раз!"
9. Опиши надежность отправки: "Отправляю Авито Доставкой в день заказа. Упаковываю бережно и надежно (пузырчатая пленка в несколько слоев + плотная картонная коробка)".
10. Используй эмодзи умеренно (не более 5-7 штук на весь текст) для структурирования абзацев.
11. Напиши текст живым, теплым и понятным языком, без использования Markdown-разметки (никаких символов * или #), так как Авито отображает их как обычный текст.
12. Общий размер текста должен быть от 600 до 1000 символов с пробелами (примерно 15–25 строк).

Напиши только текст описания. Без заголовков и вводных слов."""

    result = ask_ai(
        prompt,
        system_role="Ты профессиональный авитолог. Пишешь структурированные, продающие тексты без использования markdown-разметки (без звездочек, без решеток).",
    )
    listing['new_description'] = result
    return listing


# ============================================================
# АГЕНТ 6 — СТАТУС И ДЕЙСТВИЕ
# ============================================================

def agent_status(listing):
    views = listing.get('views', 0)
    contacts = listing.get('contacts', 0)
    photos = listing.get('photos_count', 0)

    ctr = 0
    if views > 0 and contacts > 0:
        ctr = contacts / views * 100

    if views == 0:
        listing['status'] = '⚠️ Нет просмотров'
        listing['action'] = 'Перевыложить срочно'
    elif views < 6:
        listing['status'] = '🔴 Очень мало просмотров'
        listing['action'] = 'Перевыложить'
    elif views < 20 and ctr < 1:
        listing['status'] = '🔴 Мало просмотров, низкий CTR'
        listing['action'] = 'Улучшить заголовок'
    elif views < 20 and ctr >= 1:
        listing['status'] = '🟡 Мало трафика'
        listing['action'] = 'Улучшить SEO'
    elif views < 50 and ctr < 1:
        listing['status'] = '🟡 Смотрят но не пишут'
        listing['action'] = 'Снизить цену или улучшить описание'
    elif views >= 50 and ctr < 1:
        listing['status'] = '🔴 Много просмотров но нет контактов'
        listing['action'] = 'Снизить цену на 10%'
    elif views >= 50 and ctr >= 2:
        listing['status'] = '🟢 Отлично'
        listing['action'] = 'Не трогать'
    else:
        listing['status'] = '🟢 Хорошо'
        listing['action'] = 'Можно улучшить'

    if photos < 5:
        listing['action'] += ' + добавить фото'

    return listing


# ============================================================
# ПАРСЕР КОНКУРЕНТОВ
# ============================================================

def get_competitors(driver, query, max_results=10):
    try:
        url = f"https://www.avito.ru/rossiya?q={query.replace(' ', '+')}"
        driver.get(url)
        time.sleep(random.uniform(4, 7))

        if check_blocked(driver):
            return []

        items = driver.find_elements(By.CSS_SELECTOR, '[data-marker="item"]')
        competitors = []

        for item in items[:max_results]:
            try:
                title = item.find_element(By.CSS_SELECTOR, '[data-marker="item-title"]').text.strip()
                price = item.find_element(By.CSS_SELECTOR, '[data-marker="item-price"]').text.strip()
                competitors.append({'title': title, 'price': price})
            except Exception:
                continue

        return competitors
    except Exception:
        return []


# ============================================================
# СОХРАНЕНИЕ В EXCEL
# ============================================================

def save_to_excel(results, filename="avito_orchestrator_результат.xlsx"):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Анализ объявлений"

    headers = [
        "№", "Заголовок", "Цена", "Фото", "Просмотры 7д",
        "Контакты 7д", "Статус", "Действие",
        "Новый заголовок", "Ключевые слова",
        "Анализ цены", "Советы по фото",
        "Новое описание", "Ссылка",
    ]

    header_fill = PatternFill("solid", start_color="1F4E79")
    header_font = Font(bold=True, color="FFFFFF", name="Arial", size=10)
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = header_align

    ws.row_dimensions[1].height = 35

    fills = {
        '⚠️': PatternFill("solid", start_color="FFC7CE"),
        '🔴': PatternFill("solid", start_color="FFC7CE"),
        '🟡': PatternFill("solid", start_color="FFEB9C"),
        '🟢': PatternFill("solid", start_color="C6EFCE"),
    }

    normal_font = Font(name="Arial", size=9)
    wrap_align = Alignment(wrap_text=True, vertical="top")

    for i, r in enumerate(results, 2):
        status = r.get('status', '')
        row_fill = next(
            (fill for key, fill in fills.items() if key in status),
            PatternFill("solid", start_color="F2F2F2"),
        )

        values = [
            i - 1,
            r.get('title', ''),
            r.get('price', ''),
            r.get('photos_count', 0),
            r.get('views', 0),
            r.get('contacts', 0),
            r.get('status', ''),
            r.get('action', ''),
            r.get('seo_title', ''),
            r.get('seo_keywords', ''),
            r.get('price_analysis', ''),
            r.get('photo_advice', ''),
            r.get('new_description', ''),
            r.get('link', ''),
        ]

        for col, val in enumerate(values, 1):
            cell = ws.cell(row=i, column=col, value=val)
            cell.font = normal_font
            cell.alignment = wrap_align
            cell.fill = row_fill

        ws.row_dimensions[i].height = 120

    col_widths = [5, 28, 10, 7, 12, 12, 25, 30, 28, 35, 30, 35, 55, 40]
    for col, width in enumerate(col_widths, 1):
        ws.column_dimensions[ws.cell(1, col).column_letter].width = width

    ws.freeze_panes = "A2"

    out_dir = r"C:\avito_agent"
    os.makedirs(out_dir, exist_ok=True)
    filepath = os.path.join(out_dir, filename)
    wb.save(filepath)
    print(f"\n💾 Сохранено: {filepath}")
    return filepath


# ============================================================
# ГЛАВНЫЙ ОРКЕСТРАТОР
# ============================================================

if __name__ == "__main__":
    print("=" * 60)
    print("🧠 ОРКЕСТРАТОР v5.5 (САМООБУЧАЮЩИЙСЯ) — Архитектура Ruflo")
    print("=" * 60)
    print("✅ Просмотры НЕ скликиваются")
    print("✅ ИСПОЛЬЗУЕТСЯ 100% БЕСПЛАТНАЯ МОДЕЛЬ: meta-llama/llama-3.3-70b-instruct:free")
    print("✅ Лимит max_tokens=1000 — РАБОТАЕТ ПРИ БАЛАНСЕ 0.00$")
    print("✅ Исключены стоп-слова: оригинал, ОАЭ, реплика, копия")
    print("✅ [САМООБУЧЕНИЕ]: Загрузка успешных кейсов из avito_export.csv")
    print("=" * 60)

    print("🧠 Инициализация базы памяти ИИ...")
    update_agent_memory()

    driver = create_driver()
    results = []
    total = 0

    try:
        # ШАГ 1. БЕЗОПАСНАЯ ИИ-ПАУЗА НА АВТОРИЗАЦИЮ
        print("🌐 Открываю Авито для верификации сессии...")
        driver.get("https://www.avito.ru/profile")
        time.sleep(5)

        if "login" in driver.current_url or "signin" in driver.current_url:
            print("\n❌ ВНИМАНИЕ: Вы не авторизованы на Авито в выделенном профиле Агента!")
            print("Пожалуйста, прямо сейчас в открывшемся окне браузера выполните вход на Авито.")
            input("После успешного входа вернитесь сюда и нажмите [Enter] для продолжения...")
            driver.get("https://www.avito.ru/profile")
            time.sleep(4)

        print("\n✅ Успешная авторизация подтверждена! Запускаю безопасный сбор...")

        listings = agent_collector(driver, max_items=2)  # ПОСТАВИЛИ 2 ДЛЯ БЫСТРОГО ТЕСТА!
        total = len(listings)

        if total == 0:
            print("❌ Объявления не найдены. Возможно IP заблокирован.")
        else:
            mins = total * 3
            print(f"\n🚀 Запускаю обработку {total} объявлений...")
            print(f"⏱  Примерное время: {mins}-{mins*2} минут\n")

            for i, listing in enumerate(listings):
                print(f"\n{'=' * 50}")
                print(f"📌 [{i+1}/{total}] {listing['title']}")
                print(f"   💰 {listing['price']} | 📸 {listing['photos_count']} фото")

                print("   🔍 Ищу конкурентов...")
                query = ' '.join(listing['title'].split()[:4])
                competitors = get_competitors(driver, query)
                print(f"   ✅ Конкурентов: {len(competitors)}")

                print("   🔑 SEO: ключевики + заголовок...")
                listing = agent_seo(listing, competitors)
                print(f"   ✅ {listing['seo_title'][:50]}")
                time.sleep(6)  # защита от 429 Rate Limit

                print("   💰 Цена: анализ рынка...")
                listing = agent_price(listing, competitors)
                time.sleep(6)

                print("   📸 Фото: советы...")
                listing = agent_photo(listing)
                time.sleep(6)

                print("   ✍️  Текст: пишу описание...")
                listing = agent_text(listing)
                time.sleep(6)

                listing = agent_status(listing)
                print(f"   {listing['status']} → {listing['action']}")

                results.append(listing)

                if (i + 1) % 10 == 0:
                    save_to_excel(results)
                    print(f"   💾 Промежуточное сохранение ({i+1}/{total})")

                smart_pause(i)

    except KeyboardInterrupt:
        print("\n⚠️ Остановлено — сохраняю результаты...")
    except Exception as e:
        print(f"\n❌ Ошибка: {e}")
    finally:
        elapsed = datetime.datetime.now() - session_start
        print(f"\n📊 Сессия: {elapsed.total_seconds()/60:.1f} мин | Запросов: {request_count}")
        try:
            driver.quit()
        except Exception:
            pass

    if results:
        save_to_excel(results)
        print(f"\n{'=' * 60}")
        print(f"✅ ГОТОВО! Обработано: {len(results)} из {total} объявлений")
        print(r"📊 Файл: C:\avito_agent\avito_orchestrator_результат.xlsx")
        print(f"{'=' * 60}")
        print("\nЦветовая индикация:")
        print("  🟢 Зелёный  — всё ок")
        print("  🟡 Жёлтый   — можно улучшить")
        print("  🔴 Красный  — нужно обновить")
        print("  ⚠️  Красный  — перевыложить срочно")
    else:
        print("❌ Нет данных для сохранения")
