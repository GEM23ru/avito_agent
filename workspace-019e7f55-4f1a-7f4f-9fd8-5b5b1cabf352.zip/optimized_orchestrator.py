"""
    print("🧠 ОРКЕСТРАТОР v5.8 (УСКОРЕННЫЙ + ОТПОЛИРОВАННЫЙ) — Архитектура Ruflo")
Магазин парфюмерии Евгения, г. Анапа.

ОТЛИЧИЕ ОТ v5.5:
  • Функция ask_ai вынесена в patch_ask_ai.py — там жёсткий таймаут 45 сек,
    очередь из 6 fallback-моделей OpenRouter, подробный лог и бэкофф на 429.
  • Больше скрипт никогда не висит на «🔑 SEO: ключевики + заголовок...».

Цепочка из 6 ИИ-агентов:
  1. agent_collector — собирает мои объявления (без захода в карточки → CPC не скликивается)
  2. agent_seo      — ключевики + новый заголовок (≤50 симв.)
  3. agent_price    — анализ цен с фильтром оригиналов
  4. agent_photo    — советы по фото
  5. agent_text     — продающее описание 600–1000 симв. без стоп-слов
  6. agent_status   — статус и рекомендация по действию

ТРЕБОВАНИЕ: рядом со скриптом должен лежать patch_ask_ai.py.
"""

import os
import re
import time
import random
import datetime
import json
import csv

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from dotenv import load_dotenv

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

# 🔧 Заменили inline client+ask_ai на устойчивый патч с fallback-очередью.
# Сам клиент OpenAI и список моделей теперь живут в patch_ask_ai.py.
from patch_ask_ai import ask_ai

load_dotenv(encoding='utf-8')

# Принудительно отключаем системные прокси — мешают Selenium и OpenRouter
os.environ['HTTP_PROXY'] = ''
os.environ['HTTPS_PROXY'] = ''
os.environ['http_proxy'] = ''
os.environ['https_proxy'] = ''

MY_PROFILE_URL = (
    "https://www.avito.ru/brands/c494d24667a34f39ee8a2bfd9d5e67fa/items/all"
    "?s=profile_search_show_all&sellerId=f5b44d614ca1fbd1a3a2c9c311810df2"
)

# Абсолютно изолированный профиль — исключает любые конфликты с личным Chrome
CHROME_USER_DATA = r"C:\avito_agent\chrome_profile"

# ============================================================
# УМНЫЕ ПАУЗЫ
# ============================================================

request_count = 0
session_start = datetime.datetime.now()

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
]


def smart_pause(request_num):
    """Пауза между объявлениями для имитации человека (защита Selenium от блока Авито).

    ⚡ v5.6: длительности уменьшены ~в 2-3 раза, т.к. в цикле на одно объявление
    мы делаем всего 2 запроса к Авито (профиль + поиск конкурентов), а не 5-10.
    """
    global request_count
    request_count += 1
    if request_count % 20 == 0:
        t = random.uniform(45, 75)
        print(f"   ☕ Большая пауза {t:.0f} сек — даём Авито отдохнуть...")
        time.sleep(t)
    elif request_count % 5 == 0:
        t = random.uniform(12, 20)
        print(f"   ⏸️  Длинная пауза {t:.0f} сек...")
        time.sleep(t)
    else:
        time.sleep(random.uniform(3, 6))


def human_scroll(driver):
    for _ in range(4):
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)


def check_blocked(driver):
    """Проверяет реальную блокировку по URL и заголовку страницы."""
    current_url = driver.current_url
    title = driver.title.lower()

    block_urls = ['blocked', 'captcha', 'sorry', 'deny']
    block_titles = ['доступ ограничен', 'доступ с вашего ip', 'captcha']

    url_blocked = any(b in current_url.lower() for b in block_urls)
    title_blocked = any(b in title for b in block_titles)

    if url_blocked or title_blocked:
        print(f"\n🚫 Блокировка! URL: {current_url}")
        print("   Жду 5 минут...")
        time.sleep(300)
        driver.refresh()
        time.sleep(5)
        return any(b in driver.current_url.lower() for b in block_urls)

    return False


# ============================================================
# ЯДРО — OpenRouter + очистка markdown
# ------------------------------------------------------------
# 🔄 ПЕРЕНЕСЕНО в patch_ask_ai.py (см. импорт в начале файла).
#    Теперь там:
#      • timeout=45 сек на запрос
#      • очередь из 6 free-моделей с автоматическим fallback
#      • экспоненциальный бэкофф на 429 RateLimit
#      • подробный лог: какая модель ответила и за сколько
# ============================================================


# ============================================================
# СИСТЕМА САМООБУЧЕНИЯ (Ruflo Self-Learning Loop) 🧠
# ============================================================

def update_agent_memory():
    """Считывает выгрузку из Авито Pro и формирует базу успешных паттернов."""
    memory_file = "avito_agent_memory.json"
    stats_file = "avito_export.csv"  # путь к выгрузке из Авито Pro

    memory_data = {
        "success_stories": [
            {
                "title": "Dolce&Gabbana L’Imperatrice 3 33 мл тестер духов",
                "price": "500 ₽",
                "metric": "2 заказа, 8 добавлений в избранное",
                "type": "Фруктово-свежий",
            },
            {
                "title": "Tom Ford White Patchouli EDP 100 мл",
                "price": "1 500 ₽",
                "metric": "2 заказа, 1 добавление в избранное",
                "type": "Селективный нишевый",
            },
        ]
    }

    if os.path.exists(stats_file):
        try:
            with open(stats_file, 'r', encoding='utf-8') as f:
                rows = list(csv.reader(f))

            headers = rows[0]
            data_rows = rows[1:]

            title_idx = headers.index('Название объявления')
            price_idx = headers.index('Цена')
            fav_idx = headers.index('Добавили в избранное')
            orders_idx = headers.index('Заказано товаров')
            contacts_idx = headers.index('Контакты')

            success_stories = []
            for r in data_rows:
                if len(r) < len(headers):
                    continue
                try:
                    orders = int(re.sub(r'\D', '', r[orders_idx])) if r[orders_idx] else 0
                    contacts = int(re.sub(r'\D', '', r[contacts_idx])) if r[contacts_idx] else 0
                    favs = int(re.sub(r'\D', '', r[fav_idx])) if r[fav_idx] else 0

                    if orders > 0 or contacts >= 2 or favs >= 4:
                        success_stories.append({
                            "title": r[title_idx].strip(),
                            "price": r[price_idx].strip(),
                            "metric": f"{orders} заказов, {contacts} контактов, {favs} в избранном",
                        })
                except Exception:
                    continue

            if success_stories:
                memory_data["success_stories"] = success_stories
                print(f"🧠 [САМООБУЧЕНИЕ] Обнаружено {len(success_stories)} успешных паттернов. Робот запомнил их!")
        except Exception as e:
            print(f"⚠️ Ошибка при анализе статистики для самообучения: {e}")

    with open(memory_file, 'w', encoding='utf-8') as f:
        json.dump(memory_data, f, ensure_ascii=False, indent=4)


def load_success_examples():
    """Загружает топ-успешных паттернов для инъекции в промт ИИ."""
    memory_file = "avito_agent_memory.json"
    if os.path.exists(memory_file):
        try:
            with open(memory_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            stories = data.get("success_stories", [])
            examples = [
                f"- '{s['title']}' за {s['price']} (Метрика успеха: {s['metric']})"
                for s in stories[:3]
            ]
            return "\n".join(examples)
        except Exception:
            pass
    return "Примеры отсутствуют."


# ============================================================
# ДРАЙВЕР (НА КРИСТАЛЬНО ЧИСТОМ ИЗОЛИРОВАННОМ ПРОФИЛЕ!)
# ============================================================

def create_driver():
    options = webdriver.ChromeOptions()
    options.add_argument(f"--user-data-dir={CHROME_USER_DATA}")
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    options.add_argument('--window-size=1920,1080')
    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options,
    )
    driver.execute_script(
        "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    )
    return driver


# ============================================================
# АГЕНТ 1 — СБОРЩИК (без захода на объявления)
# ============================================================

def agent_collector(driver, max_items=89):
    print("\n" + "=" * 50)
    print("🤖 АГЕНТ 1: СБОРЩИК")
    print("⚠️  Режим: БЕЗ захода на объявления — просмотры не скликиваются")
    print("=" * 50)

    driver.get(MY_PROFILE_URL)
    time.sleep(6)

    if check_blocked(driver):
        return []

    listings = []
    seen_links = set()
    page = 1

    while len(listings) < max_items:
        print(f"   📄 Страница {page}...")
        time.sleep(3)

        items = driver.find_elements(By.CSS_SELECTOR, '[class*="iva-item"]')
        if not items:
            print("   ⚠️ Объявления не найдены")
            break

        for item in items:
            if len(listings) >= max_items:
                break
            try:
                title = item.find_element(By.CSS_SELECTOR, '[data-marker="item-title"]').text.strip()
                price = item.find_element(By.CSS_SELECTOR, '[data-marker="item-price"]').text.strip()
                link = item.find_element(By.CSS_SELECTOR, 'a[itemprop="url"]').get_attribute('href')

                if not title or link in seen_links:
                    continue

                description = ""
                try:
                    meta = item.find_element(By.CSS_SELECTOR, 'meta[itemprop="description"]')
                    description = meta.get_attribute('content').strip()
                except Exception:
                    pass

                photos_count = 0
                try:
                    photos = item.find_elements(By.CSS_SELECTOR, 'img')
                    photos_count = max(0, len(photos) - 1)
                except Exception:
                    pass

                seen_links.add(link)
                listings.append({
                    'title': title,
                    'price': price,
                    'link': link,
                    'description': description,
                    'photos_count': photos_count,
                    'views': 0,
                    'contacts': 0,
                    'favorites': 0,
                    'seo_keywords': '',
                    'seo_title': '',
                    'seo_keyword_analysis': '',
                    'price_analysis': '',
                    'photo_advice': '',
                    'new_description': '',
                    'status': '',
                    'action': '',
                })
            except Exception:
                continue

        print(f"   ✅ Собрано: {len(listings)}")

        prev_count = len(seen_links)
        human_scroll(driver)
        time.sleep(3)

        new_items = driver.find_elements(By.CSS_SELECTOR, '[class*="iva-item"]')
        if len(new_items) <= len(items) and len(seen_links) == prev_count:
            print("   ℹ️ Новых объявлений нет — завершаю сбор")
            break

        page += 1

    print(f"✅ АГЕНТ 1 завершил: {len(listings)} объявлений")
    return listings


# ============================================================
# АГЕНТ 2 — SEO (двухшаговый, с адаптивной памятью)
# ============================================================

def agent_seo(listing, competitors):
    competitors_titles = "\n".join([
        f"- {c['title']} | {c['price']}" for c in competitors
    ]) or "Нет данных"

    success_examples = load_success_examples()

    keyword_prompt = f"""Ты SEO-специалист по Авито. Найди реальные поисковые запросы покупателей.

ТОВАР: {listing['title']}

ОБЪЯВЛЕНИЯ КОНКУРЕНТОВ:
{competitors_titles}

ЭТАЛОННЫЕ ЛОТЫ ИЗ НАШЕЙ ПАМЯТИ УСПЕШНЫХ ПРОДАЖ:
{success_examples}

Проанализируй и выполни:

ВЫСОКОЧАСТОТНЫЕ запросы (ищут часто):
[3-4 фразы]

СРЕДНЕЧАСТОТНЫЕ запросы (ищут регулярно):
[3-4 фразы]

НИЗКОЧАСТОТНЫЕ запросы (ищут точечно):
[2-3 фразы]

КЛЮЧЕВЫЕ_СЛОВА: слово1, слово2, слово3, слово4, слово5, слово6, слово7

ВНИМАНИЕ: последнюю строку начни ровно с метки "КЛЮЧЕВЫЕ_СЛОВА:" (без кавычек),
после двоеточия перечисли РОВНО 7 слов через запятую. Это критично для парсера."""

    keyword_result = ask_ai(
        keyword_prompt,
        system_role="Ты SEO-специалист маркетплейсов. Отвечай чётко по формату. Никакого markdown.",
    )

    title_prompt = f"""Напиши заголовок для объявления на Авито.

ТОВАР: {listing['title']}
ЦЕНА: {listing['price']}
ГОРОД ПРОДАВЦА: Анапа, Краснодарский край
КЛЮЧЕВЫЕ СЛОВА:
{keyword_result}

ПРАВИЛА:
- Длина ровно до 50 символов (СТРОГО, Авито не пропустит длиннее!).
- Первым словом пиши категорию: "Духи", "Парфюм", "Мужские духи", "Женские духи" или "Мини-парфюм" (это главный поисковый ключ!).
- ВАЖНО про бренд: пиши ПОЛНОЕ название бренда на английском, затем модель/линейку, затем объём.
  Примеры правильных заголовков:
    • "Женские духи Lancome Magie Noire 25 мл"
    • "Духи Escentric Molecules 05 унисекс 20 мл"  ← бренд "Escentric Molecules" целиком!
    • "Мужские духи Tom Ford Oud Wood 50 мл"
  НЕ дробите бренд из двух слов скобками! НЕ путайте бренд и название аромата.
- Если помещается — продублируй бренд кириллицей через пробел или скобки: "Lancome Ланком", "Tom Ford (Том Форд)".
- Пол: мужские / женские / унисекс (если применимо).
- Обязательно укажи объем: "100 мл", "25 мл", "200 мл" и т.д.
- ЗАПРЕЩЕНО писать слова: "Авито Доставка", "Москва", "копия", "реплика", "ОАЭ", "аналог", "оригинал".
- Никаких восклицательных знаков и лишних спецсимволов.
- Никакого форматирования — только текст в одну строку.

Проверь длину заголовка перед выдачей. Напиши только заголовок. Одна строка."""

    new_title = ask_ai(
        title_prompt,
        system_role="Ты копирайтер для Авито. Пишешь только заголовок — одну строку без форматирования.",
    )

    # === НАДЁЖНЫЙ ПАРСЕР КЛЮЧЕВЫХ СЛОВ ===
    # 1) Сначала ищем строку с явной меткой КЛЮЧЕВЫЕ_СЛОВА:
    keywords_line = ""
    m = re.search(r'КЛЮЧЕВЫЕ[_ ]СЛОВА\s*:?\s*(.+)', keyword_result, re.IGNORECASE)
    if m:
        keywords_line = m.group(1).strip()
    else:
        # 2) Fallback: старая логика
        lines = keyword_result.split('\n')
        for i, line in enumerate(lines):
            if 'главны' in line.lower() or '7 слов' in line.lower() or 'заголовка' in line.lower():
                if i + 1 < len(lines):
                    keywords_line = lines[i + 1].strip()
                break
        # 3) Fallback 2: последняя непустая строка, если в ней есть запятые
        if not keywords_line:
            non_empty = [l.strip() for l in lines if l.strip()]
            for line in reversed(non_empty):
                if ',' in line and len(line.split(',')) >= 3:
                    keywords_line = line
                    break
        # 4) Совсем плохо — собираем из заголовка товара
        if not keywords_line:
            keywords_line = ', '.join(listing['title'].split()[:7])

    # Чистим возможные следы markdown/скобок типа [перечисли...]
    keywords_line = re.sub(r'^\[.*?\]\s*', '', keywords_line)
    keywords_line = keywords_line.strip(' ,;:')

    listing['seo_keywords'] = keywords_line
    listing['seo_title'] = new_title
    listing['seo_keyword_analysis'] = keyword_result
    return listing


# ============================================================
# АГЕНТ 3 — ЦЕНА (с умным фильтром оригиналов)
# ============================================================

def agent_price(listing, competitors):
    try:
        my_price_val = int(re.sub(r'\D', '', listing['price']))
    except Exception:
        my_price_val = 1500

    competitors_prices = "\n".join([
        f"- {c['title']}: {c['price']}" for c in competitors
    ]) or "Нет данных"

    prompt = f"""Ты аналитик цен на Авито для парфюмерии класса ЛЮКС-ТЕСТЕР (производство Дубай).
Внимание: наш сегмент — качественные люкс-тестеры и масла, их средняя рыночная цена составляет 1200–1800 руб за 100 мл.
Если среди конкурентов в списке ниже попадаются ОРИГИНАЛЫ с ценами более 3500–25000 руб, игнорируй эти высокие оригинальные цены! Нам нельзя конкурировать с оригинальным рынком.

МОЁ ОБЪЯВЛЕНИЕ:
Товар: {listing['title']}
Моя цена: {listing['price']}

КОНКУРЕНТЫ:
{competitors_prices}

ПРАВИЛА РЕКОМЕНДАЦИИ ЦЕНЫ:
1. Посчитай среднюю цену конкурентов исключительно в сегменте люкс-тестеров.
2. Если все конкуренты продают оригиналы дороже 3500 руб — оставь мою цену {listing['price']}.
3. ЗАПРЕЩЕНО рекомендовать цену больше чем в 1.5 раза от моей текущей цены ({my_price_val} руб).
   Покупатели уже привыкли к моей цене, резкий рост = потеря трафика.
4. Если моя цена близка к среднерыночной (±20%) — оставь как есть.
5. Снижение цены допустимо только если конкуренты в моей нише дешевле на 30%+.

Отвечай строго в таком формате без форматирования:

СРЕДНЯЯ ЦЕНА КОНКУРЕНТОВ: [число] руб
РЕКОМЕНДУЕМАЯ ЦЕНА: [число] руб
МОЯ ПОЗИЦИЯ: [дешевле рынка / в рынке / дороже рынка]
ВЫВОД: [одно предложение что делать с ценой, исходя строго из сегмента люкс-тестеров/масел]"""

    result = ask_ai(
        prompt,
        system_role="Ты аналитик цен в сегменте люкс-парфюмерии. Отвечай строго по формату без markdown.",
    )

    try:
        rec_price_match = re.search(r'РЕКОМЕНДУЕМАЯ ЦЕНА:\s*(\d+)', result)
        if rec_price_match:
            rec_price_val = int(rec_price_match.group(1))
            # Защита 1: рекомендация выше 3000 при моей <=1800 — это рынок оригиналов
            if rec_price_val > 3000 and my_price_val <= 1800:
                result = re.sub(
                    r'РЕКОМЕНДУЕМАЯ ЦЕНА: \d+ руб',
                    f'РЕКОМЕНДУЕМАЯ ЦЕНА: {my_price_val} руб',
                    result,
                )
                result = re.sub(
                    r'МОЯ ПОЗИЦИЯ: .*',
                    'МОЯ ПОЗИЦИЯ: в рынке (люкс-тестеры)',
                    result,
                )
                result += "\n⚠️ Примечание: ИИ отфильтровал завышенные цены оригиналов. Сохраняйте цену для тестера."
            # Защита 2: рекомендация выше 1.5x от моей цены — слишком резкий рост
            elif rec_price_val > my_price_val * 1.5 and my_price_val > 0:
                capped = int(my_price_val * 1.2)  # допускаем максимум +20%
                result = re.sub(
                    r'РЕКОМЕНДУЕМАЯ ЦЕНА: \d+ руб',
                    f'РЕКОМЕНДУЕМАЯ ЦЕНА: {capped} руб',
                    result,
                )
                result += f"\n⚠️ Примечание: ИИ предложил резкий рост ({rec_price_val}₽), скрипт ограничил до +20% ({capped}₽)."
    except Exception:
        pass

    listing['price_analysis'] = result
    return listing


# ============================================================
# АГЕНТ 4 — ФОТО
# ============================================================

def agent_photo(listing):
    warn = ("КРИТИЧНО: фото меньше 5 штук — это убивает продажи! Скажи об этом первым пунктом."
            if listing['photos_count'] < 5 else "")

    prompt = f"""Ты эксперт по продажам на Авито.

Товар: {listing['title']}
Фото в объявлении: {listing['photos_count']} шт.

{warn}

Дай 3 конкретных совета по фото для роста продаж.
Пиши простым текстом без форматирования.
Каждый совет с новой строки начиная с цифры."""

    result = ask_ai(
        prompt,
        system_role="Ты эксперт по визуальному контенту. Пишешь простым текстом без форматирования.",
    )
    listing['photo_advice'] = result
    return listing


# ============================================================
# АГЕНТ 5 — ТЕКСТ (с памятью самообучения, без стоп-слов)
# ============================================================

def agent_text(listing):
    keywords = listing.get('seo_keywords', '')
    success_examples = load_success_examples()
    current_desc = listing['description'][:400] if listing['description'] else 'отсутствует'

    prompt = f"""Ты — выдающийся копирайтер и эксперт по продажам парфюмерии на Авито.
Твоя задача — написать безопасное, дорогое и продающее описание для объявления на тарифе CPC (оплата за клик).

ТОВАР: {listing['title']}
ЦЕНА: {listing['price']}
ТЕКУЩЕЕ ОПИСАНИЕ: {current_desc}
КЛЮЧЕВЫЕ СЛОВА: {keywords}

НАША ЛОКАЛЬНАЯ ПАМЯТЬ УСПЕШНЫХ ПРОДАЖ (Ориентируйся на этот стиль структуры и подачи):
{success_examples}

СТРОГИЕ ПРАВИЛА БЕЗОПАСНОСТИ (Защита от блокировок):
1. КАТЕГОРИЧЕСКИ ЗАПРЕЩЕНО использовать слова: "ОАЭ", "реплика", "копия", "аналог", "1 в 1", "1:1", "ААА+", "дубликат", "имитация", "подделка", "фейк", "оригинал". Если в текущем описании есть эти слова — удали их безвозвратно!
2. Для обозначения высокого качества используй исключительно безопасные фразы: "Премиальное качество (Дубай)", "Люкс-тестер (Premium)", "Качество Люкс", "Исполнение: Европа", "Батч-код бьется/совпадает на коробке и флаконе".
3. ЗАПРЕЩЕНО упоминать города "Москва", "м.", "метро". Продавец из Анапы! Последняя строка описания ВСЕГДА должна быть: "Авито Доставка или самовывоз, Анапа."

ПРАВИЛА КОНВЕРСИИ ДЛЯ ТАРИФА CPC (Снижение скликивания):
4. Не используй воду и канцелярит. Начни сразу с названия товара, его объема и главного факта. Например: "Мужские духи [Бренд] [Название] [Объем] мл в премиальном исполнении люкс-тестера!"
5. Честно распиши состояние товара: коробка запечатана в слюду, состояние флакона идеальное (без сколов и царапин). НЕ пиши "без запахов" — у духов не бывает посторонних запахов, это звучит абсурдно. (Если в текущем описании указаны дефекты коробки или уценка — перенеси это в новый текст со специальной пометкой "ВНИМАНИЕ (Уценка за дефект упаковки)").
6. Напиши пирамиду нот аромата ОДИН раз в формате "Верхние ноты: ..., Средние ноты: ..., Базовые ноты: ...". НЕ перечисляй ноты повторно через запятую отдельным абзацем — это дублирование, читателю мешает. Опиши стойкость (в среднем 4–6 часов на коже, до суток на одежде) и характер шлейфа простым человеческим языком.
7. Добавь интерактивный триггер для чата (Акция): "Напишите мне в чат кодовое слово [КЛЮЧЕВОЕ СЛОВО на тему аромата] прямо сейчас — и к вашему заказу я бесплатно добавлю мини-пробник другого селективного парфюма в подарок!"
8. Обязательно вставь блок про покупку нескольких товаров со скидкой через Корзину (это увеличивает средний чек):
   "🛒 ХОТИТЕ СЭКОНОМИТЬ? Добавьте этот товар в корзину Авито вместе с другими ароматами из моего профиля (у меня их более 80!). При заказе от 2-х любых позиций вы получите скидку 5% в корзине и заплатите за доставку всего один раз!"
9. Опиши надежность отправки: "Отправляю Авито Доставкой в день заказа. Упаковываю бережно и надежно (пузырчатая пленка в несколько слоев + плотная картонная коробка)".
10. Используй эмодзи умеренно (не более 5-7 штук на весь текст) для структурирования абзацев.
11. Напиши текст живым, теплым и понятным языком, без использования Markdown-разметки (никаких символов * или #), так как Авито отображает их как обычный текст. НИКОГДА не ставь знаки ударения над гласными (например, не пиши "показа́й", "снима́й" — это выглядит странно в карточке Авито).
12. Общий размер текста СТРОГО от 600 до 950 символов с пробелами (примерно 15–22 строки). НЕ превышай 1000 символов ни при каких обстоятельствах.

Напиши только текст описания. Без заголовков и вводных слов."""

    result = ask_ai(
        prompt,
        system_role="Ты профессиональный авитолог. Пишешь структурированные, продающие тексты без использования markdown-разметки (без звездочек, без решеток).",
    )
    result = _polish_description(result)
    listing['new_description'] = result
    return listing


def _polish_description(text: str) -> str:
    """Финальная пост-обработка описания: убираем ударения, чистим, обрезаем по абзацам."""
    if not text or text.startswith('❌'):
        return text

    # 1. Снимаем русские ударения (комбинирующий акут U+0301)
    text = text.replace('\u0301', '')

    # 2. Гарантируем последнюю строку про Анапу (если ИИ её забыл)
    anapa_line = "Авито Доставка или самовывоз, Анапа."
    if anapa_line not in text:
        text = text.rstrip() + "\n" + anapa_line

    # 3. Если перебор по длине > 1000 — режем по абзацам, сохраняя строку про Анапу
    MAX_LEN = 1000
    if len(text) > MAX_LEN:
        # Удаляем "не критичные" абзацы по порядку: дублирующее перечисление нот через запятую,
        # потом длинные эмодзи-блоки, пока не уложимся.
        paragraphs = [p.strip() for p in text.split('\n') if p.strip()]
        # Защищаем последнюю строку с Анапой
        anapa_idx = -1
        for i, p in enumerate(paragraphs):
            if anapa_line in p:
                anapa_idx = i
        # Сначала ищем дубликаты нот (перечисление, в котором уже есть слова "Верхние/Средние/Базовые" в соседнем)
        cleaned = []
        seen_notes_pyramid = False
        for p in paragraphs:
            has_pyramid = ('верхние' in p.lower() and 'базовые' in p.lower()) or \
                          ('верхние ноты' in p.lower())
            if has_pyramid:
                seen_notes_pyramid = True
            cleaned.append(p)
        # Если есть пирамида + просто длинное перечисление "кэшмеран, бергамот, ..." — оно дублирует
        if seen_notes_pyramid:
            cleaned = [
                p for p in cleaned
                if not (re.match(r'^[А-Яа-яёЁ\-,\s]+$', p) and p.count(',') >= 4
                        and 'верхние' not in p.lower() and 'базовые' not in p.lower()
                        and len(p) > 60)
            ]
        text = "\n".join(cleaned)

        # Если всё ещё длинно — режем абзацы с конца (кроме последнего про Анапу)
        if len(text) > MAX_LEN:
            paragraphs = [p.strip() for p in text.split('\n') if p.strip()]
            while len(text) > MAX_LEN and len(paragraphs) > 3:
                # Удаляем предпоследний абзац (сохраняя Анапу в самом конце)
                if anapa_line in paragraphs[-1]:
                    paragraphs.pop(-2)
                else:
                    paragraphs.pop(-1)
                text = "\n".join(paragraphs)

    return text.strip()


# ============================================================
# АГЕНТ 6 — СТАТУС И ДЕЙСТВИЕ
# ============================================================

def agent_status(listing):
    views = listing.get('views', 0)
    contacts = listing.get('contacts', 0)
    photos = listing.get('photos_count', 0)

    ctr = 0
    if views > 0 and contacts > 0:
        ctr = contacts / views * 100

    if views == 0:
        listing['status'] = '⚠️ Нет просмотров'
        listing['action'] = 'Перевыложить срочно'
    elif views < 6:
        listing['status'] = '🔴 Очень мало просмотров'
        listing['action'] = 'Перевыложить'
    elif views < 20 and ctr < 1:
        listing['status'] = '🔴 Мало просмотров, низкий CTR'
        listing['action'] = 'Улучшить заголовок'
    elif views < 20 and ctr >= 1:
        listing['status'] = '🟡 Мало трафика'
        listing['action'] = 'Улучшить SEO'
    elif views < 50 and ctr < 1:
        listing['status'] = '🟡 Смотрят но не пишут'
        listing['action'] = 'Снизить цену или улучшить описание'
    elif views >= 50 and ctr < 1:
        listing['status'] = '🔴 Много просмотров но нет контактов'
        listing['action'] = 'Снизить цену на 10%'
    elif views >= 50 and ctr >= 2:
        listing['status'] = '🟢 Отлично'
        listing['action'] = 'Не трогать'
    else:
        listing['status'] = '🟢 Хорошо'
        listing['action'] = 'Можно улучшить'

    if photos < 5:
        listing['action'] += ' + добавить фото'

    return listing


# ============================================================
# ПАРСЕР КОНКУРЕНТОВ
# ============================================================

def get_competitors(driver, query, max_results=10):
    try:
        url = f"https://www.avito.ru/rossiya?q={query.replace(' ', '+')}"
        driver.get(url)
        time.sleep(random.uniform(4, 7))

        if check_blocked(driver):
            return []

        items = driver.find_elements(By.CSS_SELECTOR, '[data-marker="item"]')
        competitors = []

        for item in items[:max_results]:
            try:
                title = item.find_element(By.CSS_SELECTOR, '[data-marker="item-title"]').text.strip()
                price = item.find_element(By.CSS_SELECTOR, '[data-marker="item-price"]').text.strip()
                competitors.append({'title': title, 'price': price})
            except Exception:
                continue

        return competitors
    except Exception:
        return []


# ============================================================
# СОХРАНЕНИЕ В EXCEL
# ============================================================

def save_to_excel(results, filename="avito_orchestrator_результат.xlsx"):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Анализ объявлений"

    headers = [
        "№", "Заголовок", "Цена", "Фото", "Просмотры 7д",
        "Контакты 7д", "Статус", "Действие",
        "Новый заголовок", "Ключевые слова",
        "Анализ цены", "Советы по фото",
        "Новое описание", "Ссылка",
    ]

    header_fill = PatternFill("solid", start_color="1F4E79")
    header_font = Font(bold=True, color="FFFFFF", name="Arial", size=10)
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = header_align

    ws.row_dimensions[1].height = 35

    fills = {
        '⚠️': PatternFill("solid", start_color="FFC7CE"),
        '🔴': PatternFill("solid", start_color="FFC7CE"),
        '🟡': PatternFill("solid", start_color="FFEB9C"),
        '🟢': PatternFill("solid", start_color="C6EFCE"),
    }

    normal_font = Font(name="Arial", size=9)
    wrap_align = Alignment(wrap_text=True, vertical="top")

    for i, r in enumerate(results, 2):
        status = r.get('status', '')
        row_fill = next(
            (fill for key, fill in fills.items() if key in status),
            PatternFill("solid", start_color="F2F2F2"),
        )

        values = [
            i - 1,
            r.get('title', ''),
            r.get('price', ''),
            r.get('photos_count', 0),
            r.get('views', 0),
            r.get('contacts', 0),
            r.get('status', ''),
            r.get('action', ''),
            r.get('seo_title', ''),
            r.get('seo_keywords', ''),
            r.get('price_analysis', ''),
            r.get('photo_advice', ''),
            r.get('new_description', ''),
            r.get('link', ''),
        ]

        for col, val in enumerate(values, 1):
            cell = ws.cell(row=i, column=col, value=val)
            cell.font = normal_font
            cell.alignment = wrap_align
            cell.fill = row_fill

        ws.row_dimensions[i].height = 120

    col_widths = [5, 28, 10, 7, 12, 12, 25, 30, 28, 35, 30, 35, 55, 40]
    for col, width in enumerate(col_widths, 1):
        ws.column_dimensions[ws.cell(1, col).column_letter].width = width

    ws.freeze_panes = "A2"

    out_dir = r"C:\avito_agent"
    os.makedirs(out_dir, exist_ok=True)
    filepath = os.path.join(out_dir, filename)
    wb.save(filepath)
    print(f"\n💾 Сохранено: {filepath}")
    return filepath


# ============================================================
# ГЛАВНЫЙ ОРКЕСТРАТОР
# ============================================================

if __name__ == "__main__":
    print("=" * 60)
    print("🧠 ОРКЕСТРАТОР v5.8 (УСКОРЕННЫЙ + ОТПОЛИРОВАННЫЙ) — Архитектура Ruflo")
    print("=" * 60)
    print("✅ Просмотры НЕ скликиваются")
    print("✅ ask_ai с fallback из 7 моделей (gpt-oss-20b → 120b → glm → kimi → ...)")
    print("⚡ УСКОРЕНИЕ: убраны time.sleep(6) между агентами, smart_pause укорочен в 2-3 раза")
    print("✅ Исключены стоп-слова: оригинал, ОАЭ, реплика, копия")
    print("✅ [САМООБУЧЕНИЕ]: Загрузка успешных кейсов из avito_export.csv")
    print("=" * 60)

    print("🧠 Инициализация базы памяти ИИ...")
    update_agent_memory()

    driver = create_driver()
    results = []
    total = 0

    try:
        # ШАГ 1. БЕЗОПАСНАЯ ИИ-ПАУЗА НА АВТОРИЗАЦИЮ
        print("🌐 Открываю Авито для верификации сессии...")
        driver.get("https://www.avito.ru/profile")
        time.sleep(5)

        if "login" in driver.current_url or "signin" in driver.current_url:
            print("\n❌ ВНИМАНИЕ: Вы не авторизованы на Авито в выделенном профиле Агента!")
            print("Пожалуйста, прямо сейчас в открывшемся окне браузера выполните вход на Авито.")
            input("После успешного входа вернитесь сюда и нажмите [Enter] для продолжения...")
            driver.get("https://www.avito.ru/profile")
            time.sleep(4)

        print("\n✅ Успешная авторизация подтверждена! Запускаю безопасный сбор...")

        listings = agent_collector(driver, max_items=10)  # ТЕСТ на 10 объявлениях после фиксов v5.8
        total = len(listings)

        if total == 0:
            print("❌ Объявления не найдены. Возможно IP заблокирован.")
        else:
            mins = total * 3
            print(f"\n🚀 Запускаю обработку {total} объявлений...")
            print(f"⏱  Примерное время: {mins}-{mins*2} минут\n")

            for i, listing in enumerate(listings):
                print(f"\n{'=' * 50}")
                print(f"📌 [{i+1}/{total}] {listing['title']}")
                print(f"   💰 {listing['price']} | 📸 {listing['photos_count']} фото")

                print("   🔍 Ищу конкурентов...")
                query = ' '.join(listing['title'].split()[:4])
                competitors = get_competitors(driver, query)
                print(f"   ✅ Конкурентов: {len(competitors)}")

                print("   🔑 SEO: ключевики + заголовок...")
                listing = agent_seo(listing, competitors)
                print(f"   ✅ {listing['seo_title'][:50]}")
                # пауза убрана — backoff уже внутри patch_ask_ai при 429

                print("   💰 Цена: анализ рынка...")
                listing = agent_price(listing, competitors)

                print("   📸 Фото: советы...")
                listing = agent_photo(listing)

                print("   ✍️  Текст: пишу описание...")
                listing = agent_text(listing)

                listing = agent_status(listing)
                print(f"   {listing['status']} → {listing['action']}")

                results.append(listing)

                if (i + 1) % 10 == 0:
                    save_to_excel(results)
                    print(f"   💾 Промежуточное сохранение ({i+1}/{total})")

                smart_pause(i)

    except KeyboardInterrupt:
        print("\n⚠️ Остановлено — сохраняю результаты...")
    except Exception as e:
        print(f"\n❌ Ошибка: {e}")
    finally:
        elapsed = datetime.datetime.now() - session_start
        print(f"\n📊 Сессия: {elapsed.total_seconds()/60:.1f} мин | Запросов: {request_count}")
        try:
            driver.quit()
        except Exception:
            pass

    if results:
        save_to_excel(results)
        print(f"\n{'=' * 60}")
        print(f"✅ ГОТОВО! Обработано: {len(results)} из {total} объявлений")
        print(r"📊 Файл: C:\avito_agent\avito_orchestrator_результат.xlsx")
        print(f"{'=' * 60}")
        print("\nЦветовая индикация:")
        print("  🟢 Зелёный  — всё ок")
        print("  🟡 Жёлтый   — можно улучшить")
        print("  🔴 Красный  — нужно обновить")
        print("  ⚠️  Красный  — перевыложить срочно")
    else:
        print("❌ Нет данных для сохранения")
