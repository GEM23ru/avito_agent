"""
🔧 ПАТЧ для optimized_orchestrator.py  (версия 2 — 2026-05-29)
==============================================================
ИСТОРИЯ ПРОБЛЕМЫ:
  • v1: брали модель meta-llama/llama-3.3-70b-instruct:free — она перегружена
    и зависала без таймаута до 10 минут.
  • v1.1: добавили fallback-очередь, но взяли ID моделей из устаревших статей —
    5 из 6 моделей просто не существуют → мгновенный 404, который SDK
    показывал как "ERR" без текста.
  • v2 (сейчас): очередь собрана из ЖИВОГО списка OpenRouter /api/v1/models
    на 29 мая 2026. Лог теперь печатает реальный текст ошибки.

ЧТО ДЕЛАЕТ ПАТЧ:
  1. ⏱  Жёсткий timeout=45 сек на один запрос.
  2. 🔁 Очередь из 7 ЖИВЫХ free-моделей с автопереключением.
  3. 📣 Подробный лог: модель / время / РЕАЛЬНЫЙ текст ошибки (а не "ERR").
  4. 📈 Экспоненциальный бэкофф на 429 (3 → 8 сек).
  5. 🛡 Защита от пустых ответов :free-моделей.
  6. 🔑 Сам подгружает .env — работает и автономно, и через импорт.
"""

import os
import re
import time
from openai import OpenAI
from dotenv import load_dotenv

# 🔑 САМИ грузим .env — патч должен работать и автономно (для теста),
# и через импорт из оркестратора. dotenv безопасен к повторному вызову.
load_dotenv(encoding='utf-8')

# Принудительно отключаем системные прокси — они часто ломают OpenRouter
os.environ['HTTP_PROXY'] = ''
os.environ['HTTPS_PROXY'] = ''
os.environ['http_proxy'] = ''
os.environ['https_proxy'] = ''

API_KEY = os.getenv("OPENROUTER_API_KEY")

# ============================================================
# КЛИЕНТ
# ============================================================
if not API_KEY:
    print("❌ КРИТИЧНО: OPENROUTER_API_KEY не найден.")
    print(r"   Проверьте, что в папке C:\avito_agent\ есть файл .env со строкой:")
    print("   OPENROUTER_API_KEY=sk-or-v1-...ваш_ключ...")
    print("   (без кавычек, без пробелов вокруг знака =)")
    raise SystemExit(1)

# Жёсткий таймаут на уровне клиента — самая надёжная защита от зависаний.
client = OpenAI(
    api_key=API_KEY,
    base_url="https://openrouter.ai/api/v1",
    timeout=45.0,       # сек на запрос
    max_retries=0,      # ретраи делаем сами — со своим логом и бэкоффом
    default_headers={
        # OpenRouter рекомендует указывать эти заголовки — иначе часть провайдеров
        # режет лимиты или отдаёт 429 чаще.
        "HTTP-Referer": "https://github.com/avito-perfume-agent",
        "X-Title": "Avito Perfume Agent",
    },
)

# ============================================================
# ОЧЕРЕДЬ FREE-МОДЕЛЕЙ (актуальна на 29 мая 2026)
# ============================================================
# Список получен напрямую из https://openrouter.ai/api/v1/models
# Порядок — от наиболее «живых и сильных» для русского/маркетинга к запасным.
# Если первая не отвечает / 429 / пусто — едем дальше по списку.
MODEL_FALLBACK_QUEUE = [
    "openai/gpt-oss-20b:free",                         # 🥇 БЫСТРЕЕ В 3-4 РАЗА чем 120b, проверено 29.05.2026
    "openai/gpt-oss-120b:free",                        # 🥈 РАБОЧАЯ! GPT-OSS 120B (для сложных промтов)
    "z-ai/glm-4.5-air:free",                           # 🥉 GLM 4.5 Air — лёгкий, стабильный
    "moonshotai/kimi-k2.6:free",                       # Kimi K2 — длинный контекст
    "nousresearch/hermes-3-llama-3.1-405b:free",       # Hermes 3 405B — мощный
    "qwen/qwen3-next-80b-a3b-instruct:free",           # Qwen 3 Next 80B (часто 429, но иногда живой)
    "meta-llama/llama-3.3-70b-instruct:free",          # старый дефолт — последняя надежда
]


def _clean_markdown(text: str) -> str:
    """Авито не рендерит markdown — снимаем все спецсимволы."""
    text = re.sub(r'\*+', '', text)
    text = re.sub(r'#+\s?', '', text)
    text = re.sub(r'`+', '', text)
    text = re.sub(r'__+', '', text)
    text = re.sub(r'\[.*?\]\(.*?\)', '', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def _classify_error(err_msg: str) -> str:
    """Короткий тег для лога — чтобы быстро понять характер сбоя."""
    low = err_msg.lower()
    if "429" in err_msg or "rate" in low:
        return "429 RateLimit"
    if "timeout" in low or "timed out" in low:
        return "TIMEOUT"
    if "401" in err_msg or "invalid api key" in low or "unauthorized" in low:
        return "AUTH"
    if "404" in err_msg or "not found" in low or "no endpoints" in low:
        return "404 NotFound"
    if "402" in err_msg or "credit" in low or "balance" in low:
        return "PAYMENT"
    if "503" in err_msg or "502" in err_msg or "upstream" in low:
        return "UPSTREAM"
    return "ERR"


def ask_ai(prompt: str, system_role: str = "Ты эксперт по продажам на Авито") -> str:
    """
    Универсальный вызов ИИ через OpenRouter с fallback-очередью.

    Параметры совместимы со старой функцией — менять вызовы НЕ нужно.
    Возвращает чистый текст (без markdown) либо "❌ Ошибка ИИ: ...".
    """
    last_error = "неизвестная причина"

    for model in MODEL_FALLBACK_QUEUE:
        backoff_steps = [3, 8]  # сек — для ретраев одной и той же модели на 429

        for attempt, wait_before in enumerate([0] + backoff_steps, 1):
            if wait_before:
                time.sleep(wait_before)

            short_name = model.split('/')[-1].replace(':free', '')
            t0 = time.time()
            try:
                response = client.chat.completions.create(
                    model=model,
                    messages=[
                        {"role": "system", "content": system_role},
                        {"role": "user", "content": prompt},
                    ],
                    max_tokens=1000,
                    temperature=0.7,
                )
                elapsed = time.time() - t0

                # Защита от пустого ответа (бывает у :free моделей)
                if not response.choices or not response.choices[0].message.content:
                    last_error = "пустой ответ от модели"
                    print(f"      ⚠️  [{short_name}] пусто за {elapsed:.1f}с — пробую следующую")
                    break

                text = response.choices[0].message.content.strip()
                if not text:
                    last_error = "пустая строка"
                    print(f"      ⚠️  [{short_name}] пустая строка за {elapsed:.1f}с")
                    break

                print(f"      ✅ [{short_name}] ответ за {elapsed:.1f}с ({len(text)} симв.)")
                return _clean_markdown(text)

            except Exception as e:
                elapsed = time.time() - t0
                err_msg = str(e)
                last_error = err_msg
                tag = _classify_error(err_msg)

                # Короткая выжимка ошибки для лога (без портянки JSON)
                short_err = err_msg.split('\n')[0][:160]

                # AUTH = ключ битый, никакой fallback не спасёт
                if tag == "AUTH":
                    print(f"      ❌ [{short_name}] AUTH ERROR — проверьте OPENROUTER_API_KEY в .env")
                    print(f"         Подробности: {short_err}")
                    return f"❌ Ошибка ИИ (auth): {short_err}"

                # PAYMENT = баланс 0 / лимит free превышен
                if tag == "PAYMENT":
                    print(f"      ❌ [{short_name}] PAYMENT — закончились free-кредиты OpenRouter")
                    print(f"         Подробности: {short_err}")
                    return f"❌ Ошибка ИИ (payment): {short_err}"

                # На 429 имеет смысл подождать и попробовать ту же модель
                if tag == "429 RateLimit" and attempt < len(backoff_steps) + 1:
                    print(f"      ⏳ [{short_name}] {tag} за {elapsed:.1f}с — ретрай через {backoff_steps[attempt-1]}с")
                    continue

                # На остальном — идём к следующей модели и показываем причину
                print(f"      ⚠️  [{short_name}] {tag} за {elapsed:.1f}с → {short_err}")
                break

    # Все модели исчерпаны
    print(f"      ❌ Все {len(MODEL_FALLBACK_QUEUE)} моделей не ответили.")
    print(f"         Последняя ошибка: {str(last_error)[:200]}")
    return f"❌ Ошибка ИИ: все free-модели OpenRouter недоступны"


# ============================================================
# Быстрый локальный тест
# ============================================================
if __name__ == "__main__":
    print("🧪 Тест patch_ask_ai v2")
    print(f"🔑 Ключ загружен: {API_KEY[:12]}...{API_KEY[-4:]} (длина {len(API_KEY)} симв.)")
    print(f"📚 Очередь моделей ({len(MODEL_FALLBACK_QUEUE)} шт.):")
    for i, m in enumerate(MODEL_FALLBACK_QUEUE, 1):
        print(f"   {i}. {m}")
    print()

    out = ask_ai(
        "Напиши одно предложение про парфюм Creed Aventus.",
        system_role="Ты парфюмер. Пиши кратко.",
    )
    print("\n📝 Ответ:\n" + out)
